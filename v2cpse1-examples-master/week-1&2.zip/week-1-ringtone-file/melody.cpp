#include "melody.hpp"
void pc_melody::play( player & p ) {
	p.play( note{ 0, 250000 } );
	p.play( note{ 494, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 494, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 466, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 466, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 440, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 440, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 440, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 659, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 440, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 440, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 440, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 659, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 784, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 784, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 784, 250000 } );
	p.play( note{ 0, 250000 } );
	p.play( note{ 659, 250000 } );
}

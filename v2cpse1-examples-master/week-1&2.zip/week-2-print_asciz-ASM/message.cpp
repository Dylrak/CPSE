#include "message.hpp"
const char * splash(){
   return "Hello brave new world!";
}
